---- ##############################################################
---- # Balise                                                     #
---- # edition du 02/02/21                                        #
---- # Fonctionne avec GPS_Tracker_ESP8266V1_WEB_FRSKY            #
---- # qui ajoute SAT, HDOP et STAT à la télémètrie de PawelSky   #
---- ##############################################################

local gps   = "GPS"
local sat   = "SAT"
local hdop  = "HDOP"
local stat  = "STAT"
local Bitmaps = {}
local options = {}

function create(zone,options)
	local widget = {zone=zone,options=options}
	return widget
end

function update(widget,options)
	widget.options = options
end

function background(widget)
end

function draw_status(widget,src)
    local msg_table = {
		[0]  = "NO STAT",
		[1]  = "NO GPS",
		[2]  = "ATT SAT",
		[3]  = "PRET"
	}
	local color = {
		[0]  = 0,
		[1]  = 0,
		[2]  = 1,
		[3]  = 2
	}
	local status = getValue(src)
	if status < 4 then status_str = msg_table[status] 
		lcd.drawText(widget.zone.x+80,widget.zone.y+44,status_str,MIDSIZE)
		local colr = color[status]
		lcd.drawBitmap(Bitmaps[colr],widget.zone.x,widget.zone.y+17 )
	end
end

function draw_gps(widget,src)
	lcd.drawText(widget.zone.x-10,widget.zone.y-10,"GPS",MIDSIZE)
	local gpsData = getValue("GPS")
	if type(gpsData) == "table" and gpsData.lat ~= nil and gpsData.lon ~= nil then
	    lcd.drawText(widget.zone.x+40,widget.zone.y-0,"Lat",SMLSIZE)
		lcd.drawText(widget.zone.x+70,widget.zone.y-10,gpsData.lat,MIDSIZE)
		lcd.drawText(widget.zone.x+40,widget.zone.y+20,"Lon",SMLSIZE)
		lcd.drawText(widget.zone.x+70,widget.zone.y+10,gpsData.lon,MIDSIZE)
	end  
end

function draw_sat(widget,src)
	local sat = getValue(src)
	lcd.drawText(widget.zone.x+1,widget.zone.y+42,"SAT",SMLSIZE)
	lcd.drawNumber(widget.zone.x+48,widget.zone.y+42,sat,SMLSIZE+RIGHT)
end

function draw_hdop(widget,src)
	local hdop = getValue(src)
	lcd.drawText(widget.zone.x-10,widget.zone.y+55,"HDOP",SMLSIZE)
	lcd.drawNumber(widget.zone.x+68,widget.zone.y+55,hdop*100,SMLSIZE+RIGHT+PREC2)
end

function refresh(widget)
	if Bitmaps[0] == nil then
		Bitmaps[0] = Bitmap.open("/WIDGETS/Balise/red.png")
		Bitmaps[1] = Bitmap.open("/WIDGETS/Balise/yellow.png")
		Bitmaps[2] = Bitmap.open("/WIDGETS/Balise/green.png")
	end
	draw_gps(widget,gps)
	draw_sat(widget,sat)
	draw_hdop(widget,hdop)
	draw_status(widget,stat)
end

return {name="Balise V2",options=options,create=create,update=update,background=background,refresh=refresh}

